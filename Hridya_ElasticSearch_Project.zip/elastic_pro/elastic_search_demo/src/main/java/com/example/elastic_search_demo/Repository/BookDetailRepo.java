package com.example.elastic_search_demo.Repository;

import com.example.elastic_search_demo.Entity.BookDetailEntity;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;


public interface BookDetailRepo extends ElasticsearchRepository<BookDetailEntity,String> {
}
