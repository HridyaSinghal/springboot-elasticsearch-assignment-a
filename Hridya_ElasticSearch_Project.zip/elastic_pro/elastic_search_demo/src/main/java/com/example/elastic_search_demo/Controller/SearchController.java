package com.example.elastic_search_demo.Controller;

import com.example.elastic_search_demo.DTO.BookDetailRequestDTO;
import com.example.elastic_search_demo.DTO.BookDetailResponseDTO;
import com.example.elastic_search_demo.Service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/search")
public class SearchController {

        @Autowired
        private SearchService searchService;

        @GetMapping
        public BookDetailResponseDTO search(@ModelAttribute BookDetailRequestDTO request) {
            return searchService.searchCourses(request);
        }
    }


