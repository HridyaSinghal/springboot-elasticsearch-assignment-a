package com.example.elastic_search_demo.Service;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.json.JsonData;
import com.example.elastic_search_demo.DTO.BookDetailRequestDTO;
import com.example.elastic_search_demo.DTO.BookDetailResponseDTO;
import com.example.elastic_search_demo.Entity.BookDetailEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SearchService {


    private ElasticsearchClient elasticsearchClient;

    @Autowired
    public SearchService(ElasticsearchClient elasticsearchClient) {
        this.elasticsearchClient = elasticsearchClient;
    }




    public BookDetailResponseDTO searchCourses(BookDetailRequestDTO request) {

        try {
            BoolQuery.Builder boolQueryBuilder = new BoolQuery.Builder();

            // Full-text search (title & description)
            if (request.getQ() != null && !request.getQ().isEmpty()) {
                MultiMatchQuery multiMatchQuery = MultiMatchQuery.of(m -> m
                        .query(request.getQ())
                        .fields("title", "description")
                );
                boolQueryBuilder.must(Query.of(q -> q.multiMatch(multiMatchQuery)));
            }

            // Exact match: category
            if (request.getCategory() != null && !request.getCategory().isEmpty()) {
                TermQuery categoryQuery = TermQuery.of(t -> t
                        .field("category.keyword")
                        .value(request.getCategory())
                );
                boolQueryBuilder.filter(Query.of(q -> q.term(categoryQuery)));
            }

            // Exact match: type
            if (request.getType() != null && !request.getType().isEmpty()) {
                TermQuery typeQuery = TermQuery.of(t -> t
                        .field("type.keyword")
                        .value(request.getType())
                );
                boolQueryBuilder.filter(Query.of(q -> q.term(typeQuery)));
            }

            // Range filter: Age
            if (request.getMinAge() != null || request.getMaxAge() != null) {
                RangeQuery.Builder ageRange = new RangeQuery.Builder().field("minAge");
                if (request.getMinAge() != null)
                    ageRange.gte(JsonData.of(request.getMinAge()));
                if (request.getMaxAge() != null)
                    ageRange.lte(JsonData.of(request.getMaxAge()));
                boolQueryBuilder.filter(Query.of(q -> q.range(ageRange.build())));
            }

            // Range filter: Price
            if (request.getMinPrice() != null || request.getMaxPrice() != null) {
                RangeQuery.Builder priceRange = new RangeQuery.Builder().field("price");
                if (request.getMinPrice() != null)
                    priceRange.gte(JsonData.of(request.getMinPrice()));
                if (request.getMaxPrice() != null)
                    priceRange.lte(JsonData.of(request.getMaxPrice()));
                boolQueryBuilder.filter(Query.of(q -> q.range(priceRange.build())));
            }

            // Date filter: nextSessionDate
            if (request.getStartDate() != null && !request.getStartDate().isEmpty()) {
                RangeQuery dateRange = RangeQuery.of(r -> r
                        .field("nextSessionDate")
                        .gte(JsonData.of(request.getStartDate()))
                );
                boolQueryBuilder.filter(Query.of(q -> q.range(dateRange)));
            }

            // Sorting logic
            String sortField;
            SortOrder sortOrder;

            if ("priceAsc".equalsIgnoreCase(request.getSort())) {
                sortField = "price";
                sortOrder = SortOrder.Asc;
            } else if ("priceDesc".equalsIgnoreCase(request.getSort())) {
                sortField = "price";
                sortOrder = SortOrder.Desc;
            } else {
                sortField = "nextSessionDate";
                sortOrder = SortOrder.Asc;
            }

            // Pagination
            int page = request.getPage() != 0 ? request.getPage() : 0;
            int size = request.getSize() != 0 ? request.getSize() : 10;
            int from = page * size;

            // Build search request
            SearchRequest searchRequest = SearchRequest.of(s -> s
                    .index("courses")  // 🔁 Replace with your actual index name if different
                    .query(Query.of(q -> q.bool(boolQueryBuilder.build())))
                    .sort(sort -> sort
                            .field(f -> f
                                    .field(sortField)
                                    .order(sortOrder)))
                    .from(from)
                    .size(size)
            );

            // Execute search
            SearchResponse<BookDetailEntity> searchResponse = elasticsearchClient.search(searchRequest, BookDetailEntity.class);

            List<BookDetailEntity> results = searchResponse.hits().hits().stream()
                    .map(hit -> hit.source())
                    .collect(Collectors.toList());

            long totalHits = searchResponse.hits().total() != null
                    ? searchResponse.hits().total().value()
                    : results.size();

            return new BookDetailResponseDTO(totalHits, results);

        } catch (IOException e) {
            throw new RuntimeException("Search failed!", e);
        }
    }
}
