package com.example.elastic_search_demo.Service;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import com.example.elastic_search_demo.Entity.BookDetailEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;

@Service
public class StartUpListener {

    private final ElasticsearchClient elasticsearchClient;
    private final ObjectMapper objectMapper;

    public StartUpListener(ElasticsearchClient elasticsearchClient, ObjectMapper objectMapper) {
        this.elasticsearchClient = elasticsearchClient;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void loadData() {
        try {
            InputStream inputStream = getClass().getResourceAsStream("/sample-courses.json");
            List<BookDetailEntity> courses = objectMapper.readValue(inputStream, new TypeReference<>() {});

            for (BookDetailEntity course : courses) {
                elasticsearchClient.index(i -> i
                        .index("courses")
                        .id(course.getId())
                        .document(course));
            }

            System.out.println("✅ Sample courses indexed into Elasticsearch.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
