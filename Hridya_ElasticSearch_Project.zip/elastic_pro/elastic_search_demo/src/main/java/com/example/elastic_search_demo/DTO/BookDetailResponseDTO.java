package com.example.elastic_search_demo.DTO;

import com.example.elastic_search_demo.Entity.BookDetailEntity;

import java.util.List;


public class BookDetailResponseDTO {
    private long total;
    private List<BookDetailEntity> courses;

    public BookDetailResponseDTO(long value, List<BookDetailEntity> courseList) {
        this.total = value;
        this.courses = courseList;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public List<BookDetailEntity> getCourses() {
        return courses;
    }

    public void setCourses(List<BookDetailEntity> courses) {
        this.courses = courses;
    }



}
