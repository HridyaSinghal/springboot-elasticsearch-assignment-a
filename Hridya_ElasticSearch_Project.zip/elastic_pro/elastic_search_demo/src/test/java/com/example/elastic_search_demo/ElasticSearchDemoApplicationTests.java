package com.example.elastic_search_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticSearchDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
